scoreboard objectives add pb_loot_mode dummy
