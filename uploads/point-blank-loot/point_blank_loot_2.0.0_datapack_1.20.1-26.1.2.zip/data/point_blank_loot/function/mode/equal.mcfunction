scoreboard players set #mode pb_loot_mode 1
tellraw @s {"text":"Point Blank: Loot mode set to Equal (same chance for every gun and item)","color":"gold"}
