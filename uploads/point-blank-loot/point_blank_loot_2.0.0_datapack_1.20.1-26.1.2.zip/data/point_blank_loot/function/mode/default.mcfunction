scoreboard players set #mode pb_loot_mode 0
tellraw @s {"text":"Point Blank: Loot mode set to Default (tiered loot)","color":"gold"}
