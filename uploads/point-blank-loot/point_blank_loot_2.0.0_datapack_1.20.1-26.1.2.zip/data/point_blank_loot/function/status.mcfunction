execute unless score #mode pb_loot_mode matches 1.. run tellraw @s {"text":"Point Blank: Loot mode: Default (tiered loot)","color":"gold"}
execute if score #mode pb_loot_mode matches 1 run tellraw @s {"text":"Point Blank: Loot mode: Equal (same chance for every gun and item)","color":"gold"}
execute if score #mode pb_loot_mode matches 2 run tellraw @s {"text":"Point Blank: Loot mode is set by the mod: use /pbloot","color":"gold"}
