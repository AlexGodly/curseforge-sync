tellraw @s {"text":"Point Blank: Loot data pack commands:","color":"gold"}
tellraw @s {"text":"/function point_blank_loot:mode/default  - tiered loot (better guns in harder structures)","color":"gray"}
tellraw @s {"text":"/function point_blank_loot:mode/equal  - every gun, ammo and attachment has the same chance","color":"gray"}
tellraw @s {"text":"/function point_blank_loot:status  - show the current mode","color":"gray"}
tellraw @s {"text":"Gun pack guns need the mod version of Point Blank: Loot.","color":"gray"}
