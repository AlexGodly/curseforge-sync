scoreboard players set #mode tacz_loot_mode 0
tellraw @s {"text":"TACZ: Loot mode set to Default (tiered loot)","color":"gold"}
