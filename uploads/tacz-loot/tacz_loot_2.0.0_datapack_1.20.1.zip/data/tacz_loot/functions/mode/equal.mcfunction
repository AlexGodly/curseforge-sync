scoreboard players set #mode tacz_loot_mode 1
tellraw @s {"text":"TACZ: Loot mode set to Equal (same chance in every chest)","color":"gold"}
