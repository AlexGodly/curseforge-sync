execute unless score #mode tacz_loot_mode matches 1.. run tellraw @s {"text":"TACZ: Loot mode: Default (tiered loot)","color":"gold"}
execute if score #mode tacz_loot_mode matches 1 run tellraw @s {"text":"TACZ: Loot mode: Equal (same chance in every chest)","color":"gold"}
execute if score #mode tacz_loot_mode matches 2 run tellraw @s {"text":"TACZ: Loot mode is set by the mod: use /taczloot","color":"gold"}
