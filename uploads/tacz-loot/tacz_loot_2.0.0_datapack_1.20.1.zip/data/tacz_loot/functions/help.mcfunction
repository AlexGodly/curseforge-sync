tellraw @s {"text":"TACZ: Loot data pack commands:","color":"gold"}
tellraw @s {"text":"/function tacz_loot:mode/default  - tiered loot (better guns in harder structures)","color":"gray"}
tellraw @s {"text":"/function tacz_loot:mode/equal  - every gun, ammo and attachment has the same chance in every chest","color":"gray"}
tellraw @s {"text":"/function tacz_loot:status  - show the current mode","color":"gray"}
tellraw @s {"text":"Gun pack guns need the mod version of TACZ: Loot.","color":"gray"}
