scoreboard objectives add tacz_loot_mode dummy
