$scoreboard players set #$(mob) mmh_off 1
$tellraw @s {"text":"$(mob) heads: OFF","color":"red"}
