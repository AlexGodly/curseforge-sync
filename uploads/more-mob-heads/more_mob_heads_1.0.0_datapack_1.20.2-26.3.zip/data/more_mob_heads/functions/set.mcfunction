$scoreboard players set #$(mob) mmh_chance $(chance)
$tellraw @s {"text":"$(mob) head chance set to $(chance)%","color":"green"}
