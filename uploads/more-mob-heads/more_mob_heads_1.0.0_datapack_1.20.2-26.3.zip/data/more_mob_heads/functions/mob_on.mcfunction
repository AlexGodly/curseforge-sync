$scoreboard players set #$(mob) mmh_off 0
$tellraw @s {"text":"$(mob) heads: ON","color":"green"}
