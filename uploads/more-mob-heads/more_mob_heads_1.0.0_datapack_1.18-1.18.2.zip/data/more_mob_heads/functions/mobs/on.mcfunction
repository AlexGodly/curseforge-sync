scoreboard players set #all mmh_off 0
tellraw @s {"text":"Mob heads: ON","color":"green"}
