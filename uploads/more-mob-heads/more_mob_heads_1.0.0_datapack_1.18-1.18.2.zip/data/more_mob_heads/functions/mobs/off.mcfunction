scoreboard players set #all mmh_off 1
tellraw @s {"text":"Mob heads: OFF","color":"red"}
