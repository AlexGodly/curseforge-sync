scoreboard players set #looting mmh_off 0
tellraw @s {"text":"Looting bonus: ON","color":"green"}
