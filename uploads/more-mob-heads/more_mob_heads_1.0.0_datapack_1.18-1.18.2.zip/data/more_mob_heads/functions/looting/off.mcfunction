scoreboard players set #looting mmh_off 1
tellraw @s {"text":"Looting bonus: OFF","color":"red"}
