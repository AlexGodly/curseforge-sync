scoreboard players set #players mmh_off 0
tellraw @s {"text":"Player heads: ON","color":"green"}
