scoreboard players set #players mmh_off 1
tellraw @s {"text":"Player heads: OFF","color":"red"}
