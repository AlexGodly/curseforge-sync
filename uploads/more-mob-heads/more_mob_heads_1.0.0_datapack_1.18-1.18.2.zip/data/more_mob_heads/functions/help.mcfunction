tellraw @s {"text":"=== More Mob Heads ===","color":"gold"}
tellraw @s {"text":"Mob heads on/off: /function more_mob_heads:mobs/on  |  /function more_mob_heads:mobs/off","color":"gray"}
tellraw @s {"text":"Player heads on/off: /function more_mob_heads:players/on  |  /function more_mob_heads:players/off","color":"gray"}
tellraw @s {"text":"Looting bonus on/off: /function more_mob_heads:looting/on  |  /function more_mob_heads:looting/off","color":"gray"}
tellraw @s {"text":"Chance for every mob: /function more_mob_heads:chance/all/<0|1|2|5|10|25|50|75|100>","color":"gray"}
tellraw @s {"text":"Chance for one mob (percent, 100 = guaranteed): /scoreboard players set #cow mmh_chance 25","color":"gray"}
tellraw @s {"text":"Player head chance: /scoreboard players set #player mmh_chance 50","color":"gray"}
tellraw @s {"text":"Turn one mob off/on: /scoreboard players set #creeper mmh_off 1  (0 = on)","color":"gray"}
tellraw @s {"text":"Show all chances: /function more_mob_heads:show  |  hide: /function more_mob_heads:hide  |  defaults: /function more_mob_heads:reset","color":"gray"}
tellraw @s {"text":"Stop one player's head from dropping: /scoreboard players set <player> mmh_nohead 1  (0 = drops again)","color":"gray"}
