tellraw @s {"text":"=== More Mob Heads ===","color":"gold"}
tellraw @s {"text":"On 1.14 to 1.16.5, drop chances are fixed (5%, bosses guaranteed, Looting helps).","color":"gray"}
tellraw @s {"text":"Stop one player's head from dropping: /scoreboard players set <player> mmh_nohead 1  (0 = drops again)","color":"gray"}
