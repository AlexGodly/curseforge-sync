scoreboard objectives add mmh_chance dummy
scoreboard objectives add mmh_off dummy
scoreboard objectives add mmh_nohead dummy
execute unless score #init mmh_off matches 1 run function more_mob_heads:reset
