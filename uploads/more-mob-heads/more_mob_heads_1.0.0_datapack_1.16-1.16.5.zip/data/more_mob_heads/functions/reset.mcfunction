scoreboard players set #init mmh_off 1
